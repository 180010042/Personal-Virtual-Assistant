import hashlib
from flask_ngrok import run_with_ngrok
from flask import Flask, request
import speech_recognition as sr
from gtts import gTTS
import playsound
import time
import os
import re
import webbrowser
import bs4
import requests
import smtplib
from bs4 import BeautifulSoup
import openpyxl
import pandas as pd

url = 'https://quiz.mygov.in'
page = requests.get(url)
soup = BeautifulSoup(page.text, 'html.parser')
title = []
start_date = []
end_date = []
start = []
end = []
for i in soup.find_all('div', attrs = {'class':'quiz-description'}):
    title1 = i.find('h3')
    start_time = i.find('div', attrs = {'class':'start-time'})
    end_time = i.find('div', attrs = {'class':'end-time'})
    title.append(title1.text)
    start_date.append(start_time.text[13:23])
    end_date.append(end_time.text[11:21])
    start.append(start_time.text[24:29])
    end.append(end_time.text[22:29])
competitions = pd.DataFrame(list(zip(title, start_date, end_date, start, end)))
competitions.columns = ['Name', 'Start date', 'End date', 'Start time', 'End time']

field_list = ['Robotics Projects', 'IOT Projects', 'Mechanical Projects', 'Machine Learning Projects', 'Computer Vision Projects']
projects1 = pd.read_excel("Projects.xlsx")

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("I am listening..")
        audio = r.listen(source,phrase_time_limit = 5)
    data = ""
    try:
        data = r.recognize_google(audio,language='en-US')
        print("You said: "+data)
    except sr.UnknownValueError:
        print("I cannot hear you")
    except sr.RequestError as e:
        print("Request Failed")
    return data

def respond(String):
    print(String)
    tts = gTTS(text=String,lang="en")
    tts.save("speech.mp3")
    playsound.playsound("speech.mp3")
    os.remove("speech.mp3")

def voice_assistant(data):
    if "project" in data:
        listening = True
        respond("Given below is the list of popular fields. Select field of your interest.")
        print(field_list)
        time.sleep(30)
        respond('Hope you have selected the field! So, which is your field of interest?')
        field = listen()
        respond('Here are some of the awesome {}'.format(field))
        for i in range(8):
            if projects1[field][i] != 'nan':
                print(projects1[field][i])
        respond("If you want to see details of the projects say 'details'.")
        res = listen()
        if res == 'details':
            webbrowser.open('https://www.skyfilabs.com/final-year-projects-for-engineering-students')
            respond("Check your default browser.")
        else:
            respond("May be you said wrong word or nothing. Try again - tell event category or")
        respond("Search other events")
        
    if "competition" in data:
        listening = True
        respond("Given below is the list of some latest competitons.")
        print(competitions)
        respond("Please keep note of your choices, so you can save them later.")
        respond('''If you want to see details of the competitions say 'details'
or if you want to search more competitions on other popular sites say 'other sites'.''')
        res = listen()
        if res == 'details':
            webbrowser.open('https://quiz.mygov.in')
            respond("Check your default browser.")
        elif res == 'other sites':
            respond("Other popular sites are Dare2Compete, Scholastic World, and citcchandigarh. Which one do you want to open?")
            res1 = listen()
            if  res1 == 'dare2compete':
                webbrowser.open('https://dare2compete.com/e/competitions/latest')
                respond("Check your default browser.")
            elif res1 == 'scholastic world':
                webbrowser.open('http://scholasticworld.blogspot.com/')
                respond("Check your default browser.")
            elif res1 == 'citcchangigarh':
                webbrowser.open('https://citcchandigarh.com/online-quiz-contests')
                respond("Check your default browser.")
            else:
                respond("May be you said wrong word or nothing. Try again - tell event category or")
        respond("Search other events.")
        
    if "workshop" in data:
        listening = True
        respond("Some of the popular platforms which provide list of popular workshops are-")
        print(('Dare2Compete', 'thecollegefever', 'Skyfilabs'))
        respond("Where do you want to search for workshops?")
        res2 = listen()
        if res2 == 'dare2compete':
            webbrowser.open('https://dare2compete.com/e/workshops?')
            respond("Check your default browser.")
        elif res2 == 'thecollegefever':
            webbrowser.open('https://www.thecollegefever.com/college-workshops')
            respond("Check your default browser.")
        elif res2 == 'skyfilabs':
            webbrowser.open('https://www.skyfilabs.com/workshops')
            respond("Check your default browser.")
        else:
            respond("May be you said wrong word or nothing. Try again - tell event category or")
        respond("Search for other events.")

    if "stop" in data:
        listening = False
        respond("See you {}. If you want to save events go to webpage.".format(users_data[session_email[-1]][0]))

    try:
        return listening
    except UnboundLocalError:
        print("timedout")

common = '''<div style='background-color:lawngreen;width:100%;height:100%;'>
                   <div style='float:left; background-color:rgba(50,205,50,0.8); width:9%;height:100%'></div>
                   <div style='float:left; background-color:rgba(173,255,47,0.5);width:7%; height:100%'></div>
                   <div style='float:left; background-color:rgba(50,205,50,0.5); width:6%; height:100%;'></div>
                   <div style='float:left; background-color:rgba(173,255,47,0.4); width:3%;height:100%'></div>'''
session_email = []
users = {}
users_data = {}
book = openpyxl.load_workbook('Registered_Users.xlsx')
sheet = book.active
df = pd.read_excel("Registered_Users.xlsx")
for row in range(len(df['Email'])):
    users_data.update({df['Email'][row]:(df['Name of User'][row], df['Password'][row], row)})

def results():
    book = openpyxl.load_workbook('Registered_Users.xlsx')
    sheet = book.active
    df = pd.read_excel("Registered_Users.xlsx")
    for row in range(len(df['Email'])):
        users_data.update({df['Email'][row]:(df['Name of User'][row], df['Password'][row], row)})
    respond('''Hello {}, I am Anna, your personal assistant, to help you with your online events registration process.
Tell me, what do you want me to search? Competitions, Workshops, or Projects'''.format(users_data[session_email[-1]][0]))
    listening = True
    while listening == True:
        data = listen()
        listening = voice_assistant(data)

class Register(object):
    def __init__(self, app):
        self.app = app

    def signup(self, username, email, password):
        users.update({email:(username, password)})

    def login(self, email, password):
        hash = hashlib.md5(password.encode())
        if users_data[email][1] == hash.hexdigest():
            return True
        else:
            return False

app = Flask(__name__)
userobj = Register(app)
run_with_ngrok(app)

@app.route("/home")
def home2():
    results()
    return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:2%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>--- Conversation Interrupted ---</h1><br><br>
                       <a href="/user/events" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Save Events</a>
                       <a href="/login" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Activate Again</a>
                   </div>
             </div>'''

            
@app.route("/signup/user", methods = ['POST'])
def reg():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        session_email.append(request.form['email'])
        hash = hashlib.md5(password.encode())
        password1 = hash.hexdigest()
        userobj.signup(username, email, password1)
        sheet.append((username, email, password1, None, None, None))
        book.save('Registered_Users.xlsx')
        return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:4%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>Registration successful!!</h1><br><br>
                       <a href="/home" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Start Conversation</a>                       
                   </div>
            </div>'''

@app.route("/login/user", methods = ['POST'])
def home():
    if request.method == 'POST':
        auth = userobj.login(request.form['email'],request.form['password'])
        session_email.append(request.form['email'])
        if auth:
            return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:4%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>Login Succesful :)</h1><br><br>
                       <a href="/home" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Start Conversation</a>
                   </div>
            </div>'''
        else:
            return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:2%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>Wrong Password :(</h1>
                   </div>
            </div>'''  

@app.route("/login")    
def login2():
    return common+'''<div style='float:left; color:white; width:50%;margin:3%;background-color:rgba(0,0,0,0.3); height:50%; padding:8%; font-size:28px'>
                        <center><h2>Login</h2></center>
                        <form action = "/login/user" method = "post">
                             <div style = "width:40%; padding-left: 35%"><label for="email">Email:</label> </div><div style = "width:40%; padding-left: 35%"><input type="email" class="form-control input-lg" placeholder="Email" name="email" required='true'></div>
                            <br> <div style = "width:40%; padding-left: 35%"><label for="password">Password:</label></div><div style = "width:40%; padding-left: 35%"><input type="password" class="form-control input-lg" placeholder="Password" name="password" required='true'></div>
                            <br>  <center><button type ='submit' style='background-color:greenyellow; color:black; border-radius:25px; padding: 10px 30px;'>Login</button></center>
                       </form>
                   </div>
            </div>'''

@app.route("/signup")    
def signup2():
    return common+'''<div style='float:left; color:white; width:50%;margin:3%;background-color:rgba(0,0,0,0.3); height:50%; padding:8%; font-size:28px'>
                        <center><h2>SignUp</h2></center>
                        <form action = "/signup/user" method = "post">
                             <div style = "width:40%; padding-left: 35%"><label for="username">Name:</label></div><div style = "width:40%; padding-left: 35%"><input type="text" class="form-control input-lg" placeholder="Username" name="username" required='true'></div><br>
                             <div style = "width:40%; padding-left: 35%"><label for="email">Email:</label></div><div style = "width:40%; padding-left: 35%"><input type="email" class="form-control input-lg" placeholder="Email" name="email" required='true'></div><br>
                             <div style = "width:40%; padding-left: 35%"><label for="password">Password:</label></div><div style = "width:40%; padding-left: 35%"><input type="password" class="form-control input-lg" placeholder="Password" name="password" required='true'>
                            </div><br><center><button type ='submit' style='background-color:greenyellow; color:black; border-radius:25px; padding: 10px 30px;'>Submit</button></center>
                       </form>
                   </div>
            </div>'''
@app.route("/")
def index(): 
    return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:5%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>Welcome Event Seekers!!</h1><br>
                       <p> Anna, your personal voice assistant will help you to search and register for the events of your choice.
                       She will timely remind you, so that you will not miss any oppourtunity.
                       For this, first you need to login to activate her. 
                       You have to do this every time you want her assistance.</p><br><br>
                       <a href="/login" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Activate Anna</a>
                    <br><p>Not yet registered? <a href="/signup" style='color:greenyellow'>SignUp here<a></p>
                   </div>
            </div>'''

book2 = openpyxl.load_workbook('User_Events.xlsx')
sheet2 = book2.active
@app.route("/user/data", methods = ['POST'])
def data():
    if request.method == 'POST':
        event_category = request.form['category']
        email = session_email[-1]
        event_name = request.form['name']
        deadline = request.form['deadline']
        sheet2.append((email, event_category, event_name, deadline))
        book2.save('User_Events.xlsx')
    return common+'''<div style='float:left;text-align:center; color:white; width:50%;margin:4%;background-color:rgba(0,0,0,0.3); height:50%; padding:6%; font-size:20px'>
                       <h1>You are logged out!!</h1><br><br>
                       <a href="/user/events" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Save Events</a>                       
                       <a href="/login" style='text-decoration:none; background-color:greenyellow; color:black; border-radius:25px; padding: 15px 40px;'>Login Again</a>                       
                   </div>'''


@app.route("/user/events")    
def events():
    return common+'''<div style='float:left; color:white; width:50%;margin:3%;background-color:rgba(0,0,0,0.3); height:50%; padding:8%; font-size:26px'>
                        <center><h2>Save Events</h2>
                        <p style = "font-size: 24px" ><b><i>Type event end date if there is no registration deadline. You can save all the events of your choice one by one.</i></b></p></center>
                        <form action = "/user/data" method = "post">
                             <div><label for="category">Event Category:</label><input type="text" style = "margin-left:11.5%"  placeholder="Workshops or Competitions" name="category" required='true'>
                             </div><div><label for="name">Event Name:</label><input type="text" style = "margin-left:16.5%" placeholder="Event name" name="name" required='true'>
                             </div><div><label for="deadline">Registration Deadline:</label><input type="text" style = "margin-left:2%" placeholder="dd/mm/yyyy" name="deadline" required='true'>
                             </div><br><center><button type ='submit' style='background-color:greenyellow; color:black; border-radius:25px; padding: 10px 30px;'>Save</button></center>
                       </form></div>'''

app.run()
