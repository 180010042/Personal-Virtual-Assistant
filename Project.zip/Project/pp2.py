from datetime import date
from time import strftime
import pandas as pd
import smtplib
import openpyxl

book = openpyxl.load_workbook('User_Events.xlsx')
sheet = book.active
user_events = pd.read_excel("User_Events.xlsx")

today = date.today()
todays_date = today.strftime("%d/%m/%Y")

todays_events = user_events.loc[user_events['Event Deadline'] == '03/09/2020']

if len(todays_events.index) != 0:
    for i in todays_events['Email']:
        todays_user_events = todays_events.loc[todays_events['Email'] == i]
        todays_user_events = todays_user_events.reset_index()
        todays_user_events.drop(['index','Email','Event Deadline'], axis = 1, inplace = True)
        message =''' Knock Knock!!
Today is the registration deadline or last date for events listed below from your store of saved events -

{}'''.format(todays_user_events)

        content = 'Subject:{}\n\n{}'.format("Reminder for today's Event Registration Deadlines.",message)

        #init gmail smtp
        mail = smtplib.SMTP('smtp.gmail.com',587)

        #identify the server
        mail.ehlo()
        mail.starttls()

        #login
        mail.login('annavoiceassistant@gmail.com','anna@voice')
        mail.sendmail('annavoiceassistant@gmail.com', i,content)
        mail.close()
        
for i in range(len(user_events['Event Deadline'])):
    if user_events['Event Deadline'][i] == '03/09/2020':
        sheet.delete_rows(idx = i+2)
    book.save('User_Events.xlsx')


